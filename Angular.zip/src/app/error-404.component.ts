import { Component } from '@angular/core';

@Component({
    selector: 'PageNotFound',
    templateUrl: './error-404.component.html',
})
export class Eror404Component{
}
