import { OrderRoutingModule } from './order.routes';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
    declarations: [],
    imports: [ CommonModule,OrderRoutingModule ],
    exports: [],
    providers: [],
})
export class OrderModule {}